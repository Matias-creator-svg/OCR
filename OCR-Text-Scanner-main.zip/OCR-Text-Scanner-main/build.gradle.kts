plugins {
    java
    application
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("net.sourceforge.tess4j:tess4j:5.6.0") // Tesseract OCR dependency
}

