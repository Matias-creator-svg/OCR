rootProject.name = "OcrExample1"

